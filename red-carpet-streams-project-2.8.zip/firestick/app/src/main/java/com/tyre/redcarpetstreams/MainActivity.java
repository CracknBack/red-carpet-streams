package com.tyre.redcarpetstreams;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import androidx.annotation.OptIn;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.datasource.DefaultDataSource;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;

/*
 * Red Carpet Streams for Fire TV.
 * The app's screens are the same web app as the LG version, shown in a WebView.
 * Video plays in Android's own player (Media3/ExoPlayer), which sits behind the WebView,
 * so the channel banner and controls still draw on top of the picture.
 */
@OptIn(markerClass = UnstableApi.class)
public class MainActivity extends Activity {
    private WebView web;
    private PlayerView pv;
    private ExoPlayer player;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private boolean metaSent = false;

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            if (player != null && player.isPlaying()) send("timeupdate");
            ui.postDelayed(this, 500);
        }
    };

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        pv = new PlayerView(this);
        pv.setUseController(false);
        pv.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        pv.setVisibility(View.GONE);
        root.addView(pv, new FrameLayout.LayoutParams(-1, -1));

        web = new WebView(this);
        web.setBackgroundColor(Color.TRANSPARENT);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "RCS");
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        web.requestFocus();

        DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
                .setAllowCrossProtocolRedirects(true)
                .setUserAgent("Mozilla/5.0 (Linux; Android) RedCarpetStreams")
                .setConnectTimeoutMs(15000)
                .setReadTimeoutMs(20000);
        player = new ExoPlayer.Builder(this)
                .setMediaSourceFactory(new DefaultMediaSourceFactory(new DefaultDataSource.Factory(this, http)))
                .build();
        pv.setPlayer(player);
        player.addListener(new Player.Listener() {
            @Override public void onPlaybackStateChanged(int st) {
                if (st == Player.STATE_BUFFERING) send("waiting");
                else if (st == Player.STATE_READY && !metaSent) { metaSent = true; send("loadedmetadata"); }
                else if (st == Player.STATE_ENDED) send("ended");
            }
            @Override public void onIsPlayingChanged(boolean playing) {
                send(playing ? "playing" : "pause");
                keepScreenOn(playing);
            }
            @Override public void onPlayerError(PlaybackException e) { send("error"); }
        });
        ui.post(ticker);

        web.loadUrl("file:///android_asset/www/index.html");
    }

    /* Tell the web app what the player is doing. */
    void send(String ev) {
        if (player == null) return;
        long pos = player.getCurrentPosition(), dur = player.getDuration();
        js("window.__rcsVideo&&__rcsVideo('" + ev + "'," + pos + "," + (dur > 0 ? dur : -1) + "," + player.isPlaying() + ")");
    }

    void js(final String code) { ui.post(() -> { if (web != null) web.evaluateJavascript(code, null); }); }

    void keepScreenOn(boolean on) {
        if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    /* Remote buttons the WebView doesn't pass on as web key presses (Back, Menu, media keys). */
    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        int code = map(e.getKeyCode());
        if (code != 0) {
            if (e.getAction() == KeyEvent.ACTION_DOWN && (e.getRepeatCount() == 0 || code != 461)) js("window.__rcsKey&&__rcsKey(" + code + ")");
            return true;
        }
        return super.dispatchKeyEvent(e);
    }

    static int map(int k) {
        switch (k) {
            case KeyEvent.KEYCODE_BACK: return 461;
            case KeyEvent.KEYCODE_MENU: return 1082;
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE: return 10252;
            case KeyEvent.KEYCODE_MEDIA_PLAY: return 415;
            case KeyEvent.KEYCODE_MEDIA_PAUSE: return 19;
            case KeyEvent.KEYCODE_MEDIA_REWIND: return 412;
            case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD: return 417;
            case KeyEvent.KEYCODE_CHANNEL_UP: return 33;
            case KeyEvent.KEYCODE_CHANNEL_DOWN: return 34;
            case KeyEvent.KEYCODE_PROG_RED: return 403;
            case KeyEvent.KEYCODE_PROG_GREEN: return 404;
            case KeyEvent.KEYCODE_PROG_YELLOW: return 405;
            case KeyEvent.KEYCODE_PROG_BLUE: return 406;
            default:
                if (k >= KeyEvent.KEYCODE_0 && k <= KeyEvent.KEYCODE_9) return 48 + (k - KeyEvent.KEYCODE_0);
                return 0;
        }
    }

    @Override protected void onPause() {
        super.onPause();
        if (player != null) player.pause();
        if (web != null) web.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
    }

    @Override protected void onDestroy() {
        ui.removeCallbacks(ticker);
        if (player != null) player.release();
        if (web != null) web.destroy();
        super.onDestroy();
    }

    /* Methods the web app can call as window.RCS.*  */
    class Bridge {
        @JavascriptInterface public void play(final String url) {
            ui.post(() -> {
                metaSent = false;
                pv.setVisibility(View.VISIBLE);
                player.setMediaItem(MediaItem.fromUri(url));
                player.prepare();
                player.play();
            });
        }
        @JavascriptInterface public void stop() {
            ui.post(() -> {
                player.stop();
                player.clearMediaItems();
                pv.setVisibility(View.GONE);
                keepScreenOn(false);
            });
        }
        @JavascriptInterface public void pause() { ui.post(() -> player.pause()); }
        @JavascriptInterface public void resume() { ui.post(() -> player.play()); }
        @JavascriptInterface public void seek(final long ms) { ui.post(() -> player.seekTo(Math.max(0, ms))); }
        @JavascriptInterface public void setLang(final String lang) {
            ui.post(() -> player.setTrackSelectionParameters(
                    player.getTrackSelectionParameters().buildUpon().setPreferredAudioLanguage(lang).build()));
        }
        @JavascriptInterface public void exit() { ui.post(MainActivity.this::finish); }
    }
}
