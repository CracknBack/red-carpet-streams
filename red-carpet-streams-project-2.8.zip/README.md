# Red Carpet Streams

One app for your LG TV, Fire TV Stick and Windows PC.

| Folder | What it is |
|---|---|
| `tv-app` | The app itself (menus, search, player screens). Used by both TVs. |
| `firestick` | The Android wrapper for the Fire TV Stick. GitHub builds this for you. |
| `windows` | The Windows desktop app. GitHub builds this for you too. |
| `.github/workflows` | The build instructions GitHub follows. |

---

## Fire TV Stick

### 1. One-time: set up GitHub (about 10 minutes)

1. Create a free account at github.com.
2. Click **+** (top right), then **New repository**. Name it `red-carpet-streams`, choose **Private**, then click **Create repository**.
3. On the new repository page, click **uploading an existing file**.
4. Unzip `red-carpet-streams-project.zip` on your computer. Open the unzipped folder and drag **everything inside it** into the GitHub page, including the `.github` folder. Then click **Commit changes**.
   - On a Mac, `.github` is hidden in Finder. Press **Cmd + Shift + .** to show it.
5. Open the **Actions** tab. You should see "Build Firestick app" running. It takes about 5–10 minutes and shows a green tick when done.
   - If the Actions tab offers templates instead, the `.github` folder didn't upload. Click **set up a workflow yourself**, paste in everything from `firestick-workflow-copy.yml`, and click **Commit changes**.

### 2. One-time: prepare the Firestick

1. On the Firestick: **Settings → My Fire TV → About**. Click the device name (e.g. "Fire TV Stick 4K") **7 times** until it says you're a developer.
2. Go back to **My Fire TV → Developer options** and turn on **Apps from Unknown Sources**. On newer models this is **Install unknown apps**; turn it on for the app below.
3. Install **Send Files to TV** from the Fire TV app store, and the same app on your phone.

### 3. Install (and every update)

1. On your phone, sign in to github.com, open the repository, and tap **Releases** (right side, or scroll down). Download the newest `RedCarpetStreams-NN.apk`.
2. In **Send Files to TV**, tap **Send** on the phone and choose the file. Tap **Receive** on the Firestick.
3. On the Firestick, open the received file and choose **Install**.

Updates install over the top, so your sign-in, favourites and progress are kept. To update, upload the changed files to GitHub (step 1.3), wait for the green tick, then repeat step 3.

### The Firestick remote

It has no coloured or number buttons, so:
- **≡ (menu button)** opens **Options**: favourite, sort order, settings.
- **Channel numbers** can't be typed on this remote; use the channel lists or search instead.
- **⏯ ⏪ ⏩** work while watching.

---

## LG TV

From the folder that contains `tv-app`:

```
ares-package tv-app
ares-install --device tv com.tyre.redcarpetstreams_2.8.0_all.ipk
```

---

## Windows PC

### Install (and every update)

1. Upload the project to GitHub as described in the Fire TV Stick section. If it's already there, upload the unzipped folder again over the top; files with the same names are replaced. GitHub then builds both the Firestick and Windows versions.
2. Wait for **Build Windows app** to show a green tick in the **Actions** tab (about 5–10 minutes).
3. On your PC, open the repository's **Releases** and download the newest `RedCarpetStreams-Windows-Setup-NN.exe`.
4. Run it. Windows will probably say **"Windows protected your PC"**, because the app isn't signed with a paid certificate. Click **More info → Run anyway**. This only happens when installing.

Updates install over the top and keep your sign-in, favourites and progress.

### Using it

- **Mouse:** point and click anywhere. The highlight follows the mouse, and the scroll wheel moves through lists.
- **Keyboard:** arrows to move, **Enter** to select, **Esc** or **Backspace** to go back, **PgUp/PgDn** to jump a page, **M** for Options (favourites, sort), **/** for search, **F** or **F11** for full screen.
- **While watching:** **Space** pauses. Double-click for full screen. **M** offers to reopen what's playing in mpv if there's no sound or picture.

### mpv

Movies and episodes in formats the built-in player can't handle open in **mpv**, a free player bundled with the app. That covers MKV files, Dolby or DTS sound, and HEVC video. mpv opens full screen; press **Q** or close it to come back. Your position is saved, so Resume works. If the built-in player can't play something, the app opens it in mpv automatically. **Settings** can make movies and series always use mpv.

## Not yet tested on real devices

- **The GitHub builds** (Firestick and Windows) haven't been run yet. If the first build fails, open the failed run, copy the red error text and send it to me.
- **Firestick playback and storage:** video uses Android's own player (Media3). Formats and saved lists haven't been checked on your Firestick yet.
- **Windows:** mpv hand-off and progress tracking were checked against a stand-in, not real mpv. As far as I know, GitHub counts Windows build time at double rate against a private project's free monthly minutes. Each build should still use only a small part of it.
